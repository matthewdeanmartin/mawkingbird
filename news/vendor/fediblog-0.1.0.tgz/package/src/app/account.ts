import { Component, ElementRef, effect, inject, signal, viewChild } from '@angular/core';
import { AuthError, MastodonAuth } from './auth';
import { Content } from './content';
import { isOwner } from './fediverse';
import { Icon } from './icon';

const PROBLEMS: Record<string, string> = {
  server: 'Enter a server name such as mastodon.social, or your handle.',
  register: 'That server did not accept this site as an app. Check the name.',
  network: 'Could not reach that server. Check the name and try again.',
};

/** The top bar's sign-in widget: a Mastodon server form, or who is signed in. */
@Component({
  selector: 'fb-account',
  imports: [Icon],
  template: `
    @if (auth.session(); as session) {
      <details class="fb-account" #menu>
        <summary class="fb-account-pill" [attr.aria-label]="'Signed in as @' + session.handle">
          @if (session.avatar) {
            <img class="fb-account-avatar" [src]="session.avatar" alt="" width="28" height="28" referrerpolicy="no-referrer" />
          } @else {
            <fb-icon name="user" />
          }
          <span class="fb-account-name">{{ session.displayName }}</span>
        </summary>
        <div class="fb-account-panel">
          <p class="fb-help">Signed in as <a [href]="session.url" rel="noopener">&#64;{{ session.handle }}</a></p>
          @if (owner(session.handle)) {
            <!-- The site's own account publishes posts; everyone else comments. -->
            <p><a class="fb-button" href="publish/">Publish posts</a></p>
          }
          <button type="button" class="fb-button fb-button-secondary" (click)="signOut()">Sign out</button>
        </div>
      </details>
    } @else {
      <details class="fb-account" [open]="auth.formOpen()" (toggle)="toggled($event)">
        <summary class="fb-button">Sign in</summary>
        <form class="fb-account-panel" (submit)="signIn($event)">
          <label for="fb-signin-server">Your Mastodon server</label>
          <div class="fb-server-row">
            <input
              #server
              id="fb-signin-server"
              name="server"
              type="text"
              inputmode="url"
              autocomplete="url"
              placeholder="mastodon.social"
              [attr.aria-invalid]="problem() ? 'true' : null"
              aria-describedby="fb-signin-help"
            />
            <button type="submit" class="fb-button" [disabled]="busy()">Continue</button>
          </div>
          <p id="fb-signin-help" class="fb-help" [class.fb-error]="problem()">
            @if (problem(); as message) {
              {{ message }}
            } @else {
              You sign in on your own server. This site can then read your profile and post
              the replies you write here, nothing else.
            }
          </p>
        </form>
      </details>
    }
  `,
})
export class Account {
  readonly auth = inject(MastodonAuth);
  private readonly siteMastodon = inject(Content).site().mastodon;
  readonly busy = signal(false);
  readonly problem = signal<string | null>(null);
  private readonly server = viewChild<ElementRef<HTMLInputElement>>('server');

  constructor() {
    // "Sign in to reply" elsewhere on the page opens this form and focuses it.
    effect(() => {
      if (this.auth.formOpen()) queueMicrotask(() => this.server()?.nativeElement.focus());
    });
  }

  owner(handle: string): boolean {
    return isOwner(handle, this.siteMastodon);
  }

  toggled(event: Event): void {
    this.auth.formOpen.set((event.target as HTMLDetailsElement).open);
  }

  async signIn(event: Event): Promise<void> {
    event.preventDefault();
    this.problem.set(null);
    this.busy.set(true);
    try {
      await this.auth.signIn(this.server()?.nativeElement.value ?? '');
    } catch (error) {
      const problem = error instanceof AuthError ? error.problem : 'network';
      this.problem.set(PROBLEMS[problem] ?? PROBLEMS['network']);
      this.busy.set(false);
    }
  }

  signOut(): void {
    void this.auth.signOut();
  }
}
