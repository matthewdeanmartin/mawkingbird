import { Routes } from '@angular/router';
import { ArchivePage } from './pages/archive';
import { AuthPage } from './pages/auth';
import { HomePage } from './pages/home';
import { PostPage } from './pages/post';
import { TagPage } from './pages/tag';

export const routes: Routes = [
  { path: '', component: HomePage },
  { path: 'archive', component: ArchivePage },
  { path: 'posts/:slug', component: PostPage },
  { path: 'tags/:tag', component: TagPage },
  // Where a reader's Mastodon server returns them after signing in. Not indexed.
  { path: 'auth', component: AuthPage },
];
