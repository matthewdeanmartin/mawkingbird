import { Routes } from '@angular/router';
import { ArchivePage } from './pages/archive';
import { HomePage } from './pages/home';
import { PostPage } from './pages/post';
import { TagPage } from './pages/tag';

export const routes: Routes = [
  { path: '', component: HomePage },
  { path: 'archive', component: ArchivePage },
  { path: 'posts/:slug', component: PostPage },
  { path: 'tags/:tag', component: TagPage },
];
