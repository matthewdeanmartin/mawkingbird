import { readFileSync } from 'node:fs';
import { ApplicationConfig, mergeApplicationConfig } from '@angular/core';
import { provideServerRendering, withRoutes } from '@angular/ssr';
import { appConfig } from './app.config';
import { serverRoutes } from './app.routes.server';
import { MANIFEST } from './content';
import { Manifest } from './model';

let cached: Manifest | null = null;

/** `fediblog build` passes the manifest's path in FEDIBLOG_MANIFEST. */
function readManifest(): Manifest {
  if (!cached) {
    const file = process.env['FEDIBLOG_MANIFEST'];
    if (!file) throw new Error('fediblog: FEDIBLOG_MANIFEST is not set. Build with `fediblog build`.');
    cached = JSON.parse(readFileSync(file, 'utf8')) as Manifest;
  }
  return cached;
}

const serverConfig: ApplicationConfig = {
  providers: [
    provideServerRendering(withRoutes(serverRoutes)),
    { provide: MANIFEST, useFactory: readManifest },
  ],
};

export const config = mergeApplicationConfig(appConfig, serverConfig);
