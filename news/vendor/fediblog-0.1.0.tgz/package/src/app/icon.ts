import { Component, computed, input } from '@angular/core';

/** Line icons for the top menu, drawn on a 24×24 grid. */
export const ICONS = {
  home: 'M3 10.5 12 3l9 7.5V21h-6v-6H9v6H3z',
  archive: 'M3 4h18v4H3z M5 8v12h14V8 M10 12h4',
  help: 'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6V14 M12 17.5h.01',
  info: 'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z M12 11v6 M12 7.5h.01',
  app: 'M14 4h6v6 M20 4l-9 9 M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5',
  rss: 'M5 4a15 15 0 0 1 15 15 M5 10a9 9 0 0 1 9 9 M6 19h.01',
  tag: 'M3 12V4h8l10 10-8 8z M7.5 7.5h.01',
  user: 'M16 8a4 4 0 1 1-8 0 4 4 0 0 1 8 0z M4 21a8 8 0 0 1 16 0',
} as const;

export type IconName = keyof typeof ICONS;

@Component({
  selector: 'fb-icon',
  template: `<svg
    class="fb-icon"
    viewBox="0 0 24 24"
    width="22"
    height="22"
    aria-hidden="true"
    focusable="false"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <path [attr.d]="path()" />
  </svg>`,
})
export class Icon {
  readonly name = input.required<IconName>();
  readonly path = computed(() => ICONS[this.name()]);
}
