/** Dates in UTC, so the prerendered text and the hydrated text always agree. */
export function formatDate(value: string, lang: string): string {
  try {
    return new Intl.DateTimeFormat(lang, { dateStyle: 'long', timeZone: 'UTC' }).format(new Date(value));
  } catch {
    return value.slice(0, 10);
  }
}

export function formatDateTime(value: string, lang: string): string {
  try {
    return new Intl.DateTimeFormat(lang, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value));
  } catch {
    return value;
  }
}

/** The machine-readable value for <time datetime>. */
export function isoDate(value: string): string {
  return new Date(value).toISOString();
}
