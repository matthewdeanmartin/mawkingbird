import { Location } from '@angular/common';
import { Component, afterNextRender, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Account } from './account';
import { MastodonAuth } from './auth';
import { Content } from './content';
import { Icon } from './icon';

/**
 * The page frame. The top bar and the body share one grid, so the title sits
 * over the left rail, the menu over the centre column and the sign-in widget
 * over the right rail:
 *
 *   | title        | menu icons   | sign in |
 *   | (blank rail) | page content | (blank) |
 */
@Component({
  selector: 'fb-root',
  imports: [RouterOutlet, Account, Icon],
  template: `
    <a class="fb-skip" [href]="skipHref">Skip to content</a>
    <header class="fb-topbar">
      <div class="fb-topbar-inner">
        <a class="fb-brand" href="./">
          @if (site.logo) {
            <img class="fb-brand-mark" [src]="site.logo" alt="" width="36" height="36" />
          }
          <span class="fb-brand-title">{{ site.title }}</span>
        </a>
        <nav class="fb-nav" aria-label="Site">
          <ul>
            <li>
              <a href="archive/" title="Archive">
                <fb-icon name="archive" /><span class="fb-nav-label">Archive</span>
              </a>
            </li>
            @for (link of site.nav; track link.href) {
              <li>
                <a [href]="link.href" [attr.title]="link.label">
                  @if (link.icon) {
                    <fb-icon [name]="link.icon" />
                  }
                  <span class="fb-nav-label" [class.fb-nav-label-always]="!link.icon">{{ link.label }}</span>
                </a>
              </li>
            }
          </ul>
        </nav>
        <div class="fb-topbar-account"><fb-account /></div>
      </div>
    </header>
    <div class="fb-layout">
      <div class="fb-rail fb-rail-left"></div>
      <div class="fb-column">
        <main id="fb-main" tabindex="-1">
          <router-outlet />
        </main>
        <footer class="fb-site-footer">
          <a href="atom.xml">Atom feed</a>
          <a href="rss.xml">RSS feed</a>
          @if (mastodonUrl) {
            <a [href]="mastodonUrl" rel="me noopener">{{ mastodonHandle }}</a>
          }
          @if (site.footer) {
            <span>{{ site.footer }}</span>
          }
        </footer>
      </div>
      <div class="fb-rail fb-rail-right"></div>
    </div>
  `,
})
export class App {
  readonly site = inject(Content).site();
  /** `@me@server.example`, written once, with its leading @. */
  readonly mastodonHandle = this.site.mastodon ? `@${this.site.mastodon.replace(/^@/, '')}` : null;
  readonly mastodonUrl = (() => {
    const match = /^@?([^@]+)@(.+)$/.exec(this.site.mastodon ?? '');
    return match ? `https://${match[2]}/@${match[1]}` : null;
  })();
  /**
   * Under <base href>, a bare "#fb-main" would resolve to the site's index.
   * This page's own base-relative path keeps the skip link on the page.
   */
  readonly skipHref = `${inject(Location)
    .path()
    .replace(/^\/|\/$/g, '')
    .replace(/.+/, '$&/')}#fb-main`;

  constructor() {
    const auth = inject(MastodonAuth);
    afterNextRender(() => auth.restore());
  }
}
