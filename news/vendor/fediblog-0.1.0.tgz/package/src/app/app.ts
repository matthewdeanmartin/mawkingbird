import { Location } from '@angular/common';
import { Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Content } from './content';

@Component({
  selector: 'fb-root',
  imports: [RouterOutlet],
  template: `
    <a class="fb-skip" [href]="skipHref">Skip to content</a>
    <header class="fb-site-header">
      <div class="fb-container fb-site-header-row">
        <a class="fb-site-title" href="./">{{ site.title }}</a>
        <nav aria-label="Site">
          <ul class="fb-nav">
            <li><a href="archive/">Archive</a></li>
            @for (link of site.nav; track link.href) {
              <li><a [href]="link.href">{{ link.label }}</a></li>
            }
          </ul>
        </nav>
      </div>
    </header>
    <main id="fb-main" class="fb-container" tabindex="-1">
      <router-outlet />
    </main>
    <footer class="fb-site-footer">
      <div class="fb-container">
        <p>
          <a href="atom.xml">Atom feed</a> · <a href="rss.xml">RSS feed</a>
          @if (mastodonUrl) {
            · <a [href]="mastodonUrl" rel="me noopener">{{ site.mastodon }}</a>
          }
        </p>
        @if (site.footer) {
          <p>{{ site.footer }}</p>
        }
        <p class="fb-generator">
          Comments are Mastodon replies. Built with
          <a href="https://www.npmjs.com/package/fediblog">fediblog</a>.
        </p>
      </div>
    </footer>
  `,
})
export class App {
  readonly site = inject(Content).site();
  /**
   * Under <base href>, a bare "#fb-main" would resolve to the site's index.
   * This page's own base-relative path keeps the skip link on the page.
   */
  readonly skipHref = `${inject(Location)
    .path()
    .replace(/^\/|\/$/g, '')
    .replace(/.+/, '$&/')}#fb-main`;
  readonly mastodonUrl = (() => {
    const match = /^@?([^@]+)@(.+)$/.exec(this.site.mastodon ?? '');
    return match ? `https://${match[2]}/@${match[1]}` : null;
  })();
}
