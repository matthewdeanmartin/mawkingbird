import { Component, inject, input } from '@angular/core';
import { Content } from '../content';
import { PostSummary, Tag } from '../model';
import { PostList } from '../post-list';
import { Seo } from '../seo';

@Component({
  selector: 'fb-tag',
  imports: [PostList],
  template: `
    @if (found) {
      <header class="fb-page-header">
        <p class="fb-kicker">Topic</p>
        <h1>{{ found.name }}</h1>
      </header>
      <fb-post-list [posts]="posts" />
    } @else {
      <h1>Topic not found</h1>
      <p><a href="./">Back to all posts</a></p>
    }
  `,
})
export class TagPage {
  /** Route parameter, bound by withComponentInputBinding. */
  readonly tag = input.required<string>();
  private readonly content = inject(Content);
  private readonly seo = inject(Seo);
  found: Tag | null = null;
  posts: PostSummary[] = [];

  ngOnInit(): void {
    const { tag, posts } = this.content.tagged(this.tag());
    this.found = tag;
    this.posts = posts;
    if (tag) {
      const path = `tags/${tag.slug}/`;
      this.seo.set({
        title: tag.name,
        description: `Posts about ${tag.name} from ${this.content.site().title}.`,
        path,
        breadcrumbs: [{ name: tag.name, path }],
      });
    }
  }
}
