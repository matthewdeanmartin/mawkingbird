import { Component, afterNextRender, computed, inject, signal } from '@angular/core';
import { MastodonAuth } from '../auth';
import { Content } from '../content';
import { formatDate } from '../format';
import { frontMatterLine, isOwner, tootLength, tootText } from '../fediverse';
import { Publishable } from '../model';
import { Seo } from '../seo';
import { SiteToots } from '../toots';

type RowState = 'linked' | 'found' | 'unpublished' | 'checking';

interface Row {
  post: Publishable;
  /** Absolute post address, as it goes in the toot. */
  url: string;
  state: RowState;
  /** The announcing toot: front matter or found on the account. */
  toot: string | null;
  text: string;
  sending: boolean;
  error: string | null;
  copied: boolean;
}

const LIMIT = 500;

/**
 * The publishing desk for the site's own Mastodon account (`mastodon` in the
 * config). Lists each post as linked (front matter names its toot), found (the
 * account already tooted it) or not published, and publishes a new toot with
 * the site's default text and hashtags, edited first if wanted. Other accounts
 * only comment; they see a note instead.
 */
@Component({
  selector: 'fb-publish',
  template: `
    <header class="fb-page-header">
      <h1>Publish</h1>
      <p class="fb-lede">Announce posts from {{ handle }}. Replies to that toot become the post's comments.</p>
    </header>
    @if (preview) {
      <p class="fb-notice">
        This is a preview copy of the site. Toots link the real address,
        <a [href]="site.canonicalUrl">{{ site.canonicalUrl }}</a>, so publish once the post is live
        there.
      </p>
    }

    @if (!auth.session()) {
      <p>Only {{ handle }} can publish here. Sign in as that account to continue.</p>
      <p><button type="button" class="fb-button" (click)="auth.formOpen.set(true)">Sign in</button></p>
    } @else if (!owner()) {
      <p>
        Only {{ handle }} can publish here. You are signed in as &#64;{{ auth.session()!.handle }},
        so you can comment on posts but not publish them.
      </p>
    } @else {
      <ol class="fb-publish-list">
        @for (row of rows(); track row.post.slug) {
          <li class="fb-card fb-publish-row" [attr.data-state]="row.state">
            <h2 class="fb-card-title"><a [href]="row.post.path">{{ row.post.title }}</a></h2>
            <p class="fb-meta">
              {{ date(row.post.date) }} ·
              @switch (row.state) {
                @case ('linked') {
                  <span class="fb-badge">Linked</span>
                }
                @case ('found') {
                  <span class="fb-badge">Found on Mastodon</span>
                }
                @case ('checking') {
                  Checking Mastodon…
                }
                @default {
                  <span class="fb-badge fb-badge-muted">Not published</span>
                }
              }
            </p>

            @if (row.toot; as toot) {
              <p><a [href]="toot" rel="noopener">See the toot</a></p>
              @if (row.state === 'found') {
                <p class="fb-help">
                  Comments already work: the post finds this toot when it loads. To save that lookup,
                  add this line to the post's front matter:
                </p>
                <div class="fb-copy-row">
                  <code class="fb-front-matter">{{ frontMatter(toot) }}</code>
                  <button type="button" class="fb-button fb-button-secondary" (click)="copy(row)">
                    {{ row.copied ? 'Copied' : 'Copy' }}
                  </button>
                </div>
              }
            } @else if (row.state === 'unpublished') {
              <form class="fb-reply-form" (submit)="publish($event, row)">
                <label [for]="'fb-toot-' + row.post.slug">Toot</label>
                <textarea
                  [id]="'fb-toot-' + row.post.slug"
                  rows="7"
                  [value]="row.text"
                  (input)="edit(row, $any($event.target).value)"
                ></textarea>
                <div class="fb-reply-send">
                  <span class="fb-help" [class.fb-error]="length(row) > limit">
                    {{ length(row) }}/{{ limit }} · public
                  </span>
                  <button
                    type="submit"
                    class="fb-button"
                    [disabled]="row.sending || !row.text.trim() || length(row) > limit"
                  >
                    {{ row.sending ? 'Publishing…' : 'Publish' }}
                  </button>
                </div>
                @if (row.error; as error) {
                  <p class="fb-help fb-error" aria-live="polite">{{ error }}</p>
                }
              </form>
            }
          </li>
        } @empty {
          <li class="fb-empty">No posts yet.</li>
        }
      </ol>
    }
  `,
})
export class PublishPage {
  readonly auth = inject(MastodonAuth);
  private readonly content = inject(Content);
  private readonly toots = inject(SiteToots);
  readonly site = this.content.site();
  readonly preview = this.site.url !== this.site.canonicalUrl;
  readonly limit = LIMIT;
  readonly handle = this.site.mastodon ? `@${this.site.mastodon.replace(/^@/, '')}` : 'the site account';
  readonly owner = computed(() => isOwner(this.auth.session()?.handle, this.site.mastodon));
  readonly rows = signal<Row[]>(
    this.content.publishable().map((post) => {
      // Always the real address, even when publishing from a preview build.
      const url = new URL(post.path, this.site.canonicalUrl).href;
      return {
        post,
        url,
        state: post.mastodon ? 'linked' : 'checking',
        toot: post.mastodon,
        text: tootText(this.site.publish.template, { ...post, url }),
        sending: false,
        error: null,
        copied: false,
      } satisfies Row;
    }),
  );

  constructor() {
    inject(Seo).set({
      title: 'Publish',
      description: `Publish posts as ${this.handle}.`,
      path: 'publish/',
      noindex: true,
    });
    afterNextRender(() => void this.check());
  }

  /** Marks unlinked posts the account has already tooted as found. */
  private async check(fresh = false): Promise<void> {
    for (const row of this.rows()) {
      if (row.state === 'linked') continue;
      const thread = await this.toots.find(row.post.path, fresh);
      this.update(row.post.slug, thread ? { state: 'found', toot: thread.url } : { state: 'unpublished' });
    }
  }

  private update(slug: string, patch: Partial<Row>): void {
    this.rows.update((rows) => rows.map((row) => (row.post.slug === slug ? { ...row, ...patch } : row)));
  }

  edit(row: Row, text: string): void {
    this.update(row.post.slug, { text, error: null });
  }

  length(row: Row): number {
    return tootLength(row.text);
  }

  async publish(event: Event, row: Row): Promise<void> {
    event.preventDefault();
    this.update(row.post.slug, { sending: true, error: null });
    try {
      // Someone may have published it since the page loaded (another tab).
      const already = await this.toots.find(row.post.path, true);
      if (already) {
        this.update(row.post.slug, { state: 'found', toot: already.url, sending: false });
        return;
      }
      const posted = await this.auth.publish(row.text.trim(), row.post.lang, `fediblog-${row.post.slug}`);
      this.update(row.post.slug, { state: 'found', toot: posted.url, sending: false });
    } catch {
      this.update(row.post.slug, {
        sending: false,
        error: 'The toot was not published. Your server may be unreachable, or you may need to sign in again.',
      });
    }
  }

  frontMatter(toot: string): string {
    return frontMatterLine(toot);
  }

  async copy(row: Row): Promise<void> {
    if (!row.toot) return;
    try {
      await navigator.clipboard.writeText(frontMatterLine(row.toot));
      this.update(row.post.slug, { copied: true });
    } catch {
      // Clipboard blocked: the line is on screen to select by hand.
    }
  }

  date(value: string): string {
    return formatDate(value, this.site.lang);
  }
}
