import { DOCUMENT } from '@angular/common';
import { Component, afterNextRender, inject, signal } from '@angular/core';
import { AuthError, MastodonAuth } from '../auth';
import { Seo } from '../seo';

const PROBLEMS: Record<string, string> = {
  denied: 'You chose not to sign in. Nothing was shared with this site.',
  state: 'This sign-in link expired or was already used. Please sign in again.',
  token: 'Your server did not complete the sign-in. Please try again.',
  network: 'Your server could not be reached. Please try again.',
};

/** Where a reader's server sends them back after they approve signing in. */
@Component({
  selector: 'fb-auth',
  template: `
    <header class="fb-page-header">
      <h1>{{ problem() ? 'Sign-in did not finish' : 'Signing you in…' }}</h1>
    </header>
    @if (problem(); as message) {
      <p>{{ message }}</p>
      <p><a href="./">Back to all posts</a></p>
    } @else {
      <p class="fb-empty" aria-live="polite">Finishing sign-in with your Mastodon server.</p>
    }
  `,
})
export class AuthPage {
  readonly problem = signal<string | null>(null);

  constructor() {
    inject(Seo).set({
      title: 'Sign in',
      description: 'Finishing sign-in with your Mastodon server.',
      path: 'auth/',
      noindex: true,
    });
    const auth = inject(MastodonAuth);
    const location = inject(DOCUMENT).location;
    afterNextRender(async () => {
      try {
        location.replace(await auth.complete(location.search));
      } catch (error) {
        const problem = error instanceof AuthError ? error.problem : 'network';
        this.problem.set(PROBLEMS[problem] ?? PROBLEMS['network']);
      }
    });
  }
}
