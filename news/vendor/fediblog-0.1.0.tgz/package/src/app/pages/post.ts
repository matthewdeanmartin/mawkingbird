import { Component, afterNextRender, inject, input, signal } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { Comments } from '../comments';
import { Content } from '../content';
import { formatDate, isoDate } from '../format';
import { MastodonThread, Post, PostSummary } from '../model';
import { Seo } from '../seo';
import { SiteToots } from '../toots';

@Component({
  selector: 'fb-post',
  imports: [Comments],
  template: `
    @if (post; as post) {
      <article class="fb-article" [attr.lang]="post.lang">
        <header class="fb-page-header">
          <h1>{{ post.title }}</h1>
          <p class="fb-meta">
            <time [attr.datetime]="iso(post.date)">{{ date(post.date) }}</time>
            @if (post.updated) {
              · Updated <time [attr.datetime]="iso(post.updated)">{{ date(post.updated) }}</time>
            }
            · {{ post.readingMinutes }} min read
          </p>
          @if (post.tags.length) {
            <ul class="fb-tags" aria-label="Tags">
              @for (tag of post.tags; track tag.slug) {
                <li><a [href]="'tags/' + tag.slug + '/'">{{ tag.name }}</a></li>
              }
            </ul>
          }
        </header>
        @if (post.image) {
          <img class="fb-hero" [src]="post.image" [alt]="post.imageAlt ?? ''" />
        }
        <div class="fb-prose" [innerHTML]="body"></div>
      </article>

      @if (post.mastodon ?? found(); as thread) {
        <fb-comments [post]="post" [thread]="thread" />
      } @else {
        <section class="fb-comments" aria-labelledby="fb-comments-title">
          <h2 id="fb-comments-title" class="fb-section-title">Comments</h2>
          <p class="fb-empty">
            Comments open once this post is shared on Mastodon. Replies to it will show up here.
            @if (mastodonUrl) {
              Follow <a [href]="mastodonUrl" rel="noopener">{{ mastodonHandle }}</a> to see it.
            }
          </p>
        </section>
      }

      <nav class="fb-pager" aria-label="More posts">
        @if (near.older; as older) {
          <a class="fb-pager-older" [href]="older.path"><span>Older</span> {{ older.title }}</a>
        }
        @if (near.newer; as newer) {
          <a class="fb-pager-newer" [href]="newer.path"><span>Newer</span> {{ newer.title }}</a>
        }
      </nav>
    } @else {
      <h1>Post not found</h1>
      <p><a href="./">Back to all posts</a></p>
    }
  `,
})
export class PostPage {
  /** Route parameter, bound by withComponentInputBinding. */
  readonly slug = input.required<string>();
  private readonly content = inject(Content);
  private readonly seo = inject(Seo);
  private readonly sanitizer = inject(DomSanitizer);
  private readonly lang = this.content.site().lang;
  private readonly handle = /^@?([^@]+)@(.+)$/.exec(this.content.site().mastodon ?? '');
  readonly mastodonHandle = this.handle ? `@${this.handle[1]}@${this.handle[2]}` : null;
  readonly mastodonUrl = this.handle ? `https://${this.handle[2]}/@${this.handle[1]}` : null;
  post: Post | null = null;
  /** The site account's toot for this post, when front matter does not name one. */
  readonly found = signal<MastodonThread | null>(null);
  private readonly toots = inject(SiteToots);

  constructor() {
    afterNextRender(async () => {
      const post = this.post;
      if (!post || post.mastodon) return;
      this.found.set(await this.toots.find(new URL(post.path, this.content.site().url).href));
    });
  }
  body: SafeHtml = '';
  near: { newer: PostSummary | null; older: PostSummary | null } = { newer: null, older: null };

  ngOnInit(): void {
    this.post = this.content.post(this.slug());
    this.near = this.content.neighbours(this.slug());
    const post = this.post;
    if (!post) return;
    // The site author's own Markdown, so its HTML is trusted (unlike replies).
    this.body = this.sanitizer.bypassSecurityTrustHtml(post.html);
    this.seo.set({
      title: post.title,
      description: post.description,
      path: post.path,
      type: 'article',
      image: post.image,
      imageAlt: post.imageAlt,
      lang: post.lang,
      published: post.date,
      modified: post.updated,
      tags: post.tags.map((tag) => tag.name),
      breadcrumbs: [{ name: post.title, path: post.path }],
    });
  }

  date(value: string): string {
    return formatDate(value, this.lang);
  }

  iso(value: string): string {
    return isoDate(value);
  }
}
