import { Component, inject, input } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { Comments } from '../comments';
import { Content } from '../content';
import { formatDate, isoDate } from '../format';
import { Post, PostSummary } from '../model';
import { Seo } from '../seo';

@Component({
  selector: 'fb-post',
  imports: [Comments],
  template: `
    @if (post; as post) {
      <article class="fb-article" [attr.lang]="post.lang">
        <header class="fb-page-header">
          <h1>{{ post.title }}</h1>
          <p class="fb-meta">
            <time [attr.datetime]="iso(post.date)">{{ date(post.date) }}</time>
            @if (post.updated) {
              · Updated <time [attr.datetime]="iso(post.updated)">{{ date(post.updated) }}</time>
            }
            · {{ post.readingMinutes }} min read
          </p>
          @if (post.tags.length) {
            <ul class="fb-tags" aria-label="Tags">
              @for (tag of post.tags; track tag.slug) {
                <li><a [href]="'tags/' + tag.slug + '/'">{{ tag.name }}</a></li>
              }
            </ul>
          }
        </header>
        @if (post.image) {
          <img class="fb-hero" [src]="post.image" [alt]="post.imageAlt ?? ''" />
        }
        <div class="fb-prose" [innerHTML]="body"></div>
      </article>

      @if (post.mastodon) {
        <fb-comments [post]="post" />
      }

      <nav class="fb-pager" aria-label="More posts">
        @if (near.older; as older) {
          <a class="fb-pager-older" [href]="older.path"><span>Older</span> {{ older.title }}</a>
        }
        @if (near.newer; as newer) {
          <a class="fb-pager-newer" [href]="newer.path"><span>Newer</span> {{ newer.title }}</a>
        }
      </nav>
    } @else {
      <h1>Post not found</h1>
      <p><a href="./">Back to all posts</a></p>
    }
  `,
})
export class PostPage {
  /** Route parameter, bound by withComponentInputBinding. */
  readonly slug = input.required<string>();
  private readonly content = inject(Content);
  private readonly seo = inject(Seo);
  private readonly sanitizer = inject(DomSanitizer);
  private readonly lang = this.content.site().lang;
  post: Post | null = null;
  body: SafeHtml = '';
  near: { newer: PostSummary | null; older: PostSummary | null } = { newer: null, older: null };

  ngOnInit(): void {
    this.post = this.content.post(this.slug());
    this.near = this.content.neighbours(this.slug());
    const post = this.post;
    if (!post) return;
    // The site author's own Markdown, so its HTML is trusted (unlike replies).
    this.body = this.sanitizer.bypassSecurityTrustHtml(post.html);
    this.seo.set({
      title: post.title,
      description: post.description,
      path: post.path,
      type: 'article',
      image: post.image,
      imageAlt: post.imageAlt,
      lang: post.lang,
      published: post.date,
      modified: post.updated,
      tags: post.tags.map((tag) => tag.name),
      breadcrumbs: [{ name: post.title, path: post.path }],
    });
  }

  date(value: string): string {
    return formatDate(value, this.lang);
  }

  iso(value: string): string {
    return isoDate(value);
  }
}
