import { Component, inject } from '@angular/core';
import { Content } from '../content';
import { formatDate, isoDate } from '../format';
import { PostSummary } from '../model';
import { Seo } from '../seo';

@Component({
  selector: 'fb-archive',
  template: `
    <header class="fb-page-header">
      <h1>Archive</h1>
      <p class="fb-lede">Every post, newest first.</p>
    </header>
    @for (group of years; track group.year) {
      <section class="fb-section" [attr.aria-labelledby]="'fb-year-' + group.year">
        <h2 class="fb-section-title" [id]="'fb-year-' + group.year">{{ group.year }}</h2>
        <ul class="fb-archive">
          @for (post of group.posts; track post.slug) {
            <li>
              <time [attr.datetime]="iso(post.date)">{{ date(post.date) }}</time>
              <a [href]="post.path">{{ post.title }}</a>
            </li>
          }
        </ul>
      </section>
    } @empty {
      <p class="fb-empty">No posts yet.</p>
    }
  `,
})
export class ArchivePage {
  private readonly content = inject(Content);
  private readonly lang = this.content.site().lang;
  readonly years: { year: string; posts: PostSummary[] }[] = [];

  constructor() {
    for (const post of this.content.posts()) {
      const year = post.date.slice(0, 4);
      const last = this.years[this.years.length - 1];
      if (last?.year === year) last.posts.push(post);
      else this.years.push({ year, posts: [post] });
    }
    inject(Seo).set({
      title: 'Archive',
      description: `Every post from ${this.content.site().title}, newest first.`,
      path: 'archive/',
      breadcrumbs: [{ name: 'Archive', path: 'archive/' }],
    });
  }

  date(value: string): string {
    return formatDate(value, this.lang);
  }

  iso(value: string): string {
    return isoDate(value);
  }
}
