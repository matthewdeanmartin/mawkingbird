import { Component, inject } from '@angular/core';
import { Content } from '../content';
import { PostList } from '../post-list';
import { Seo } from '../seo';

@Component({
  selector: 'fb-home',
  imports: [PostList],
  template: `
    <header class="fb-page-header">
      <h1>{{ site.title }}</h1>
      <p class="fb-lede">{{ site.description }}</p>
    </header>
    <fb-post-list [posts]="posts" />
    @if (tags.length) {
      <nav class="fb-section" aria-labelledby="fb-topics">
        <h2 id="fb-topics" class="fb-section-title">Topics</h2>
        <ul class="fb-tags">
          @for (tag of tags; track tag.slug) {
            <li><a [href]="'tags/' + tag.slug + '/'">{{ tag.name }} ({{ tag.count }})</a></li>
          }
        </ul>
      </nav>
    }
  `,
})
export class HomePage {
  private readonly content = inject(Content);
  readonly site = this.content.site();
  readonly posts = this.content.posts();
  readonly tags = this.content.tags();

  constructor() {
    inject(Seo).set({ title: this.site.title, description: this.site.description, path: '' });
  }
}
