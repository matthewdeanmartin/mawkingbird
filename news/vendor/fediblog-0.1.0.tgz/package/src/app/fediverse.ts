/**
 * Mastodon replies → the comment thread. No Angular and no imports, so the
 * logic runs under `node --test` as well as in the app.
 */

export interface MastodonEmoji {
  shortcode: string;
  url: string;
  static_url?: string;
}

export interface MastodonAccount {
  id: string;
  acct: string;
  display_name: string;
  username: string;
  url: string;
  avatar_static?: string;
  emojis?: MastodonEmoji[];
}

export interface MastodonMedia {
  id: string;
  type: string;
  url: string | null;
  remote_url?: string | null;
  description?: string | null;
}

export interface MastodonStatus {
  id: string;
  uri: string;
  url?: string | null;
  in_reply_to_id: string | null;
  visibility: string;
  created_at: string;
  content: string;
  spoiler_text?: string;
  account: MastodonAccount;
  emojis?: MastodonEmoji[];
  media_attachments?: MastodonMedia[];
}

export interface ThreadReply {
  id: string;
  /** Nesting below the post's own status, from 1; capped at MAX_DEPTH for layout. */
  depth: number;
  byAuthor: boolean;
  url: string;
  createdAt: string;
  authorName: string;
  authorHandle: string;
  authorUrl: string;
  avatar: string | null;
  spoiler: string;
  content: string;
  media: { url: string; label: string }[];
}

export const MAX_DEPTH = 4;

/** Only replies anyone can see belong on a public page. */
const VISIBLE = new Set(['public', 'unlisted']);

export function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** Replaces `:shortcode:` with the server's custom emoji image. */
export function emojify(html: string, emojis: MastodonEmoji[] | undefined): string {
  if (!emojis?.length) return html;
  const byCode = new Map(emojis.map((emoji) => [emoji.shortcode, emoji]));
  // Only in text between tags, never inside an attribute.
  return html.replace(/(^|>)([^<]*)/g, (_whole, open: string, text: string) => {
    const replaced = text.replace(/:([A-Za-z0-9_]+):/g, (match, code: string) => {
      const emoji = byCode.get(code);
      if (!emoji) return match;
      const src = escapeHtml(emoji.static_url || emoji.url);
      return `<img class="fb-emoji" src="${src}" alt=":${code}:" title=":${code}:" />`;
    });
    return open + replaced;
  });
}

function matchesAny(status: MastodonStatus, hidden: Set<string>): boolean {
  return hidden.has(status.id) || hidden.has(status.uri) || (!!status.url && hidden.has(status.url));
}

/**
 * Orders replies depth-first under the post's status, oldest first at each
 * level. A hidden or non-public reply takes its own replies with it.
 */
export function buildThread(
  rootId: string,
  descendants: MastodonStatus[],
  options: { hidden?: string[]; authorId?: string | null } = {},
): ThreadReply[] {
  const hidden = new Set(options.hidden ?? []);
  const children = new Map<string, MastodonStatus[]>();
  for (const status of descendants) {
    const parent = status.in_reply_to_id ?? rootId;
    const list = children.get(parent) ?? [];
    list.push(status);
    children.set(parent, list);
  }
  for (const list of children.values()) {
    list.sort((a, b) => Date.parse(a.created_at) - Date.parse(b.created_at));
  }
  const out: ThreadReply[] = [];
  const visit = (parentId: string, depth: number) => {
    for (const status of children.get(parentId) ?? []) {
      if (!VISIBLE.has(status.visibility) || matchesAny(status, hidden)) continue;
      out.push(toReply(status, Math.min(depth, MAX_DEPTH), options.authorId ?? null));
      visit(status.id, depth + 1);
    }
  };
  visit(rootId, 1);
  return out;
}

function toReply(status: MastodonStatus, depth: number, authorId: string | null): ThreadReply {
  const account = status.account;
  const name = account.display_name?.trim() || account.username;
  return {
    id: status.id,
    depth,
    byAuthor: !!authorId && account.id === authorId,
    url: status.url || status.uri,
    createdAt: status.created_at,
    authorName: emojify(escapeHtml(name), account.emojis),
    authorHandle: `@${account.acct}`,
    authorUrl: account.url,
    avatar: account.avatar_static || null,
    spoiler: status.spoiler_text ? emojify(escapeHtml(status.spoiler_text), status.emojis) : '',
    content: emojify(status.content, status.emojis),
    media: (status.media_attachments ?? [])
      .map((media) => ({
        url: media.url || media.remote_url || '',
        label: media.description?.trim() || `Attached ${media.type}`,
      }))
      .filter((media) => media.url),
  };
}

/**
 * A reader's server from what they typed: `example.social`,
 * `https://example.social/` or a handle like `@me@example.social`.
 * Returns the lower-case host, or null.
 */
export function serverHost(input: string): string | null {
  let host = input.trim();
  const handle = /^@?[\w.-]+@([\w.-]+)$/.exec(host);
  if (handle) host = handle[1];
  host = host.replace(/^https?:\/\//i, '').replace(/\/.*$/, '');
  return /^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(host) ? host.toLowerCase() : null;
}

/**
 * The reader's server's "interact with this post" page: Mastodon shows the
 * post there, signed in, ready to reply.
 */
export function interactionUrl(server: string, statusUrl: string): string | null {
  const host = serverHost(server);
  return host ? `https://${host}/authorize_interaction?uri=${encodeURIComponent(statusUrl)}` : null;
}

/** What signing in asks for: who you are, finding the post, and posting replies. */
export const SCOPES = 'read:accounts read:search write:statuses';

/** The server's OAuth consent page. */
export function authorizeUrl(origin: string, clientId: string, redirectUri: string, state: string): string {
  const params = new URLSearchParams({
    response_type: 'code',
    client_id: clientId,
    redirect_uri: redirectUri,
    scope: SCOPES,
    state,
  });
  return `${origin}/oauth/authorize?${params}`;
}

/** `me` on example.social → `me@example.social`; remote accts already have a domain. */
export function fullHandle(acct: string, origin: string): string {
  return acct.includes('@') ? acct : `${acct}@${new URL(origin).host}`;
}

/**
 * Only return to a page on this site after signing in, never elsewhere.
 * `home` is the site's front page (document.baseURI), the fallback.
 */
export function safeReturn(target: string | undefined, home: string): string {
  try {
    const url = new URL(target || home, home);
    return url.origin === new URL(home).origin ? url.href : home;
  } catch {
    return home;
  }
}
