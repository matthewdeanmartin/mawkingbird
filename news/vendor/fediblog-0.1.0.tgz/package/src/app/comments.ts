import { Component, afterNextRender, inject, input, signal } from '@angular/core';
import { Content } from './content';
import { formatDateTime } from './format';
import { Post } from './model';
import { MastodonStatus, ThreadReply, buildThread, interactionUrl } from './thread';

const SERVER_KEY = 'fediblog:server';

type LoadState = 'waiting' | 'loading' | 'ready' | 'unavailable';

async function getJson<T>(url: string): Promise<T> {
  const response = await fetch(url, { headers: { Accept: 'application/json' } });
  if (!response.ok) throw new Error(`${response.status} ${url}`);
  return (await response.json()) as T;
}

/**
 * Replies to the post's Mastodon status, fetched in the browser after load.
 * Never prerendered: other people's posts are not published for indexing.
 */
@Component({
  selector: 'fb-comments',
  template: `
    @let thread = post().mastodon!;
    <section class="fb-comments" aria-labelledby="fb-comments-title">
      <h2 id="fb-comments-title" class="fb-section-title">Comments</h2>
      <p class="fb-comments-intro">
        Comments are replies to
        <a [href]="thread.url" rel="noopener">this post on Mastodon</a>. Reply there and your
        reply appears here.
      </p>

      <div class="fb-reply-actions">
        <button type="button" class="fb-button" (click)="toggleServerForm()" [attr.aria-expanded]="askServer()">
          Reply on Mastodon
        </button>
        @if (thread.mawkingbird) {
          <a class="fb-button fb-button-secondary" [href]="thread.mawkingbird" rel="nofollow noopener">
            Reply in Mawkingbird
          </a>
        }
      </div>

      @if (askServer()) {
        <form class="fb-server-form" (submit)="reply($event)">
          <label for="fb-server">Your Mastodon server</label>
          <div class="fb-server-row">
            <input
              id="fb-server"
              name="server"
              type="text"
              inputmode="url"
              autocomplete="url"
              placeholder="mastodon.social"
              [value]="server()"
              (input)="server.set($any($event.target).value)"
              [attr.aria-invalid]="serverError() ? 'true' : null"
              aria-describedby="fb-server-help"
            />
            <button type="submit" class="fb-button">Go</button>
          </div>
          <p id="fb-server-help" class="fb-help" [class.fb-error]="serverError()">
            @if (serverError()) {
              Enter a server name such as mastodon.social, or your handle.
            } @else {
              Your server opens this post so you can reply as yourself.
            }
          </p>
        </form>
      }

      @switch (state()) {
        @case ('ready') {
          @if (replies().length) {
            <ol class="fb-thread">
              @for (reply of replies(); track reply.id) {
                <li class="fb-reply" [attr.data-depth]="reply.depth" [class.fb-reply-author]="reply.byAuthor">
                  <header class="fb-reply-header">
                    @if (reply.avatar) {
                      <img class="fb-avatar" [src]="reply.avatar" alt="" width="40" height="40" loading="lazy" referrerpolicy="no-referrer" />
                    }
                    <span class="fb-reply-who">
                      <a class="fb-reply-name" [href]="reply.authorUrl" rel="nofollow noopener ugc" [innerHTML]="reply.authorName"></a>
                      @if (reply.byAuthor) {
                        <span class="fb-badge">Author</span>
                      }
                      <span class="fb-reply-handle">{{ reply.authorHandle }}</span>
                    </span>
                    <a class="fb-reply-time" [href]="reply.url" rel="nofollow noopener ugc">
                      <time [attr.datetime]="reply.createdAt">{{ when(reply.createdAt) }}</time>
                    </a>
                  </header>
                  @if (reply.spoiler) {
                    <details class="fb-cw">
                      <summary [innerHTML]="reply.spoiler"></summary>
                      <div class="fb-reply-body" [innerHTML]="reply.content"></div>
                    </details>
                  } @else {
                    <div class="fb-reply-body" [innerHTML]="reply.content"></div>
                  }
                  @if (reply.media.length) {
                    <ul class="fb-media">
                      @for (media of reply.media; track media.url) {
                        <li><a [href]="media.url" rel="nofollow noopener ugc">{{ media.label }}</a></li>
                      }
                    </ul>
                  }
                </li>
              }
            </ol>
          } @else {
            <p class="fb-empty">No replies yet. Be the first.</p>
          }
        }
        @case ('unavailable') {
          <p class="fb-empty">
            The replies could not be loaded here.
            <a [href]="thread.url" rel="noopener">Read the replies on Mastodon</a>.
          </p>
        }
        @default {
          <p class="fb-empty" aria-live="polite">
            @if (state() === 'loading') {
              Loading replies…
            } @else {
              <a [href]="thread.url" rel="noopener">Read the replies on Mastodon</a>.
            }
          </p>
        }
      }
    </section>
  `,
})
export class Comments {
  readonly post = input.required<Post>();
  private readonly lang = inject(Content).site().lang;
  readonly state = signal<LoadState>('waiting');
  readonly replies = signal<ThreadReply[]>([]);
  readonly askServer = signal(false);
  readonly server = signal('');
  readonly serverError = signal(false);

  constructor() {
    afterNextRender(() => {
      try {
        this.server.set(localStorage.getItem(SERVER_KEY) ?? '');
      } catch {
        // Storage blocked: the reader types their server each time.
      }
      void this.load();
    });
  }

  private async load(): Promise<void> {
    const thread = this.post().mastodon;
    if (!thread) return;
    this.state.set('loading');
    const api = `${thread.server}/api/v1/statuses/${encodeURIComponent(thread.id)}`;
    try {
      const [status, context] = await Promise.all([
        getJson<MastodonStatus>(api),
        getJson<{ descendants: MastodonStatus[] }>(`${api}/context`),
      ]);
      this.replies.set(
        buildThread(thread.id, context.descendants ?? [], {
          hidden: this.post().hiddenReplies,
          authorId: status.account?.id ?? null,
        }),
      );
      this.state.set('ready');
    } catch {
      // Authorized fetch, limited federation, a deleted status or no network.
      this.state.set('unavailable');
    }
  }

  toggleServerForm(): void {
    this.askServer.update((open) => !open);
    this.serverError.set(false);
  }

  reply(event: Event): void {
    event.preventDefault();
    const thread = this.post().mastodon;
    const url = thread ? interactionUrl(this.server(), thread.url) : null;
    this.serverError.set(!url);
    if (!url) return;
    try {
      localStorage.setItem(SERVER_KEY, this.server().trim());
    } catch {
      // Not remembered; still works.
    }
    window.open(url, '_blank', 'noopener');
  }

  when(value: string): string {
    return formatDateTime(value, this.lang);
  }
}
