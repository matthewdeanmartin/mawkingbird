import { Component, ElementRef, afterNextRender, inject, input, signal, viewChild } from '@angular/core';
import { MastodonAuth } from './auth';
import { Content } from './content';
import { formatDateTime } from './format';
import { MastodonThread, Post } from './model';
import { MastodonStatus, ThreadReply, buildThread, fullHandle, interactionUrl } from './fediverse';

const SERVER_KEY = 'fediblog:server';

type LoadState = 'waiting' | 'loading' | 'ready' | 'unavailable';

async function getJson<T>(url: string): Promise<T> {
  const response = await fetch(url, { headers: { Accept: 'application/json' } });
  if (!response.ok) throw new Error(`${response.status} ${url}`);
  return (await response.json()) as T;
}

interface ReplyTarget {
  url: string;
  handle: string;
}

/**
 * Replies to the post's Mastodon status, fetched in the browser after load.
 * Never prerendered: other people's posts are not published for indexing.
 *
 * Signed in (header widget), a reader replies right here, from their own
 * account. Signed out, they can sign in, open the post on their own server, or
 * open it in Mawkingbird.
 */
@Component({
  selector: 'fb-comments',
  template: `
    @let t = thread();
    <section class="fb-comments" aria-labelledby="fb-comments-title">
      <h2 id="fb-comments-title" class="fb-section-title">Comments</h2>
      <p class="fb-comments-intro">
        Comments are replies to
        <a [href]="t.url" rel="noopener">this post on Mastodon</a>.
      </p>

      @if (auth.session(); as session) {
        <form class="fb-reply-form" (submit)="send($event)">
          <label for="fb-reply-text">Reply as &#64;{{ session.handle }}</label>
          @if (target(); as to) {
            <p class="fb-help">
              Replying to {{ to.handle }} ·
              <button type="button" class="fb-link-button" (click)="replyTo(null)">reply to the post instead</button>
            </p>
          }
          <textarea
            #text
            id="fb-reply-text"
            name="text"
            rows="4"
            [value]="draft()"
            (input)="draft.set($any($event.target).value)"
          ></textarea>
          <div class="fb-reply-send">
            <span class="fb-help">{{ draft().length }} characters · public</span>
            <button type="submit" class="fb-button" [disabled]="sending() || !draft().trim()">
              {{ sending() ? 'Posting…' : 'Post reply' }}
            </button>
          </div>
          <p class="fb-help" [class.fb-error]="sendError()" aria-live="polite">
            @if (sendError()) {
              Your reply was not posted. Your server may be unreachable, or you may need to sign in again.
            } @else if (sentUrl(); as url) {
              Posted. <a [href]="url" rel="noopener">See it on your server</a>. It appears here once
              it reaches this thread, usually within a minute.
            }
          </p>
        </form>
      } @else {
        <div class="fb-reply-actions">
          <button type="button" class="fb-button" (click)="auth.formOpen.set(true)">Sign in to reply</button>
          <button type="button" class="fb-button fb-button-secondary" (click)="toggleServerForm()" [attr.aria-expanded]="askServer()">
            Reply on your server
          </button>
          @if (t.mawkingbird) {
            <a class="fb-button fb-button-secondary" [href]="t.mawkingbird" rel="nofollow noopener">
              Reply in Mawkingbird
            </a>
          }
        </div>

        @if (askServer()) {
          <form class="fb-server-form" (submit)="reply($event)">
            <label for="fb-server">Your Mastodon server</label>
            <div class="fb-server-row">
              <input
                id="fb-server"
                name="server"
                type="text"
                inputmode="url"
                autocomplete="url"
                placeholder="mastodon.social"
                [value]="server()"
                (input)="server.set($any($event.target).value)"
                [attr.aria-invalid]="serverError() ? 'true' : null"
                aria-describedby="fb-server-help"
              />
              <button type="submit" class="fb-button">Go</button>
            </div>
            <p id="fb-server-help" class="fb-help" [class.fb-error]="serverError()">
              @if (serverError()) {
                Enter a server name such as mastodon.social, or your handle.
              } @else {
                Your server opens this post so you can reply there.
              }
            </p>
          </form>
        }
      }

      @switch (state()) {
        @case ('ready') {
          @if (replies().length) {
            <ol class="fb-thread">
              @for (reply of replies(); track reply.id) {
                <li class="fb-reply" [attr.data-depth]="reply.depth" [class.fb-reply-author]="reply.byAuthor">
                  <header class="fb-reply-header">
                    @if (reply.avatar) {
                      <img class="fb-avatar" [src]="reply.avatar" alt="" width="40" height="40" loading="lazy" referrerpolicy="no-referrer" />
                    }
                    <span class="fb-reply-who">
                      <a class="fb-reply-name" [href]="reply.authorUrl" rel="nofollow noopener ugc" [innerHTML]="reply.authorName"></a>
                      @if (reply.byAuthor) {
                        <span class="fb-badge">Author</span>
                      }
                      <span class="fb-reply-handle">{{ reply.authorHandle }}</span>
                    </span>
                    <a class="fb-reply-time" [href]="reply.url" rel="nofollow noopener ugc">
                      <time [attr.datetime]="reply.createdAt">{{ when(reply.createdAt) }}</time>
                    </a>
                  </header>
                  @if (reply.spoiler) {
                    <details class="fb-cw">
                      <summary [innerHTML]="reply.spoiler"></summary>
                      <div class="fb-reply-body" [innerHTML]="reply.content"></div>
                    </details>
                  } @else {
                    <div class="fb-reply-body" [innerHTML]="reply.content"></div>
                  }
                  @if (reply.media.length) {
                    <ul class="fb-media">
                      @for (media of reply.media; track media.url) {
                        <li><a [href]="media.url" rel="nofollow noopener ugc">{{ media.label }}</a></li>
                      }
                    </ul>
                  }
                  @if (auth.session()) {
                    <button type="button" class="fb-link-button fb-reply-to" (click)="replyTo({ url: reply.url, handle: reply.authorHandle })">
                      Reply
                    </button>
                  }
                </li>
              }
            </ol>
          } @else {
            <p class="fb-empty">No replies yet. Be the first.</p>
          }
        }
        @case ('unavailable') {
          <p class="fb-empty">
            The replies could not be loaded here.
            <a [href]="t.url" rel="noopener">Read the replies on Mastodon</a>.
          </p>
        }
        @default {
          <p class="fb-empty" aria-live="polite">
            @if (state() === 'loading') {
              Loading replies…
            } @else {
              <a [href]="t.url" rel="noopener">Read the replies on Mastodon</a>.
            }
          </p>
        }
      }
    </section>
  `,
})
export class Comments {
  readonly post = input.required<Post>();
  /** The toot whose replies are the comments: front matter, or found by SiteToots. */
  readonly thread = input.required<MastodonThread>();
  readonly auth = inject(MastodonAuth);
  private readonly lang = inject(Content).site().lang;
  readonly state = signal<LoadState>('waiting');
  readonly replies = signal<ThreadReply[]>([]);
  readonly askServer = signal(false);
  readonly server = signal('');
  readonly serverError = signal(false);

  /** The post author's handle, mentioned at the start of a new reply. */
  private authorHandle = '';
  readonly target = signal<ReplyTarget | null>(null);
  readonly draft = signal('');
  readonly sending = signal(false);
  readonly sendError = signal(false);
  readonly sentUrl = signal<string | null>(null);
  private readonly text = viewChild<ElementRef<HTMLTextAreaElement>>('text');

  constructor() {
    afterNextRender(() => {
      try {
        this.server.set(localStorage.getItem(SERVER_KEY) ?? '');
      } catch {
        // Storage blocked: the reader types their server each time.
      }
      void this.load();
    });
  }

  private async load(): Promise<void> {
    const thread = this.thread();
    if (this.state() !== 'ready') this.state.set('loading');
    const api = `${thread.server}/api/v1/statuses/${encodeURIComponent(thread.id)}`;
    try {
      const [status, context] = await Promise.all([
        getJson<MastodonStatus>(api),
        getJson<{ descendants: MastodonStatus[] }>(`${api}/context`),
      ]);
      if (status.account && !this.authorHandle) {
        this.authorHandle = `@${fullHandle(status.account.acct, thread.server)}`;
        if (!this.draft()) this.draft.set(`${this.authorHandle} `);
      }
      this.replies.set(
        buildThread(thread.id, context.descendants ?? [], {
          hidden: this.post().hiddenReplies,
          authorId: status.account?.id ?? null,
        }),
      );
      this.state.set('ready');
    } catch {
      // Authorized fetch, limited federation, a deleted status or no network.
      if (this.state() !== 'ready') this.state.set('unavailable');
    }
  }

  replyTo(target: ReplyTarget | null): void {
    this.target.set(target);
    const mention = target?.handle ?? this.authorHandle;
    this.draft.set(mention ? `${mention} ` : '');
    const box = this.text()?.nativeElement;
    box?.scrollIntoView({ block: 'center' });
    box?.focus();
  }

  async send(event: Event): Promise<void> {
    event.preventDefault();
    const thread = this.thread();
    if (!this.draft().trim()) return;
    this.sending.set(true);
    this.sendError.set(false);
    this.sentUrl.set(null);
    try {
      const posted = await this.auth.reply(this.target()?.url ?? thread.url, this.draft().trim());
      this.sentUrl.set(posted.url);
      this.target.set(null);
      this.draft.set(this.authorHandle ? `${this.authorHandle} ` : '');
      // Federation takes a moment; look again once it has probably arrived.
      setTimeout(() => void this.load(), 8000);
    } catch {
      this.sendError.set(true);
    } finally {
      this.sending.set(false);
    }
  }

  toggleServerForm(): void {
    this.askServer.update((open) => !open);
    this.serverError.set(false);
  }

  reply(event: Event): void {
    event.preventDefault();
    const url = interactionUrl(this.server(), this.thread().url);
    this.serverError.set(!url);
    if (!url) return;
    try {
      localStorage.setItem(SERVER_KEY, this.server().trim());
    } catch {
      // Not remembered; still works.
    }
    window.open(url, '_blank', 'noopener');
  }

  when(value: string): string {
    return formatDateTime(value, this.lang);
  }
}
