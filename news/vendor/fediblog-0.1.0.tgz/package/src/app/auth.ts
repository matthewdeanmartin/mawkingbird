import { DOCUMENT, isPlatformBrowser } from '@angular/common';
import { Injectable, PLATFORM_ID, inject, signal } from '@angular/core';
import { Content } from './content';
import { MastodonStatus, SCOPES, authorizeUrl, fullHandle, safeReturn, serverHost } from './fediverse';

/** A reader signed in with their own Mastodon account. */
export interface Session {
  /** https://example.social */
  origin: string;
  token: string;
  /** me@example.social */
  handle: string;
  displayName: string;
  avatar: string | null;
  url: string;
}

interface AppRegistration {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
}

interface Pending {
  origin: string;
  state: string;
  returnTo: string;
}

/** Storage keys. The `fediblog:` prefix keeps them apart from a host app's own. */
const SESSION_KEY = 'fediblog:session';
const APPS_KEY = 'fediblog:apps';
const PENDING_KEY = 'fediblog:pending';

export type AuthProblem = 'server' | 'register' | 'denied' | 'state' | 'token' | 'network';

export class AuthError extends Error {
  constructor(readonly problem: AuthProblem) {
    super(problem);
  }
}

function read<T>(storage: () => Storage, key: string): T | null {
  try {
    const raw = storage().getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

function write(storage: () => Storage, key: string, value: unknown): void {
  try {
    if (value === null) storage().removeItem(key);
    else storage().setItem(key, JSON.stringify(value));
  } catch {
    // Storage blocked: signing in lasts for this page only.
  }
}

const local = () => localStorage;
const session = () => sessionStorage;

function randomState(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return [...bytes].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function json<T>(response: Response, problem: AuthProblem): Promise<T> {
  if (!response.ok) throw new AuthError(problem);
  return (await response.json()) as T;
}

/**
 * Signing in with the reader's own Mastodon account (OAuth, in the browser).
 * The site registers itself as an app on each reader's server, once, and keeps
 * the token in this browser only. It is a separate sign-in from any app on the
 * same site.
 */
@Injectable({ providedIn: 'root' })
export class MastodonAuth {
  private readonly document = inject(DOCUMENT);
  private readonly browser = isPlatformBrowser(inject(PLATFORM_ID));
  private readonly site = inject(Content).site();

  readonly session = signal<Session | null>(null);
  /** Opens the header's sign-in form, e.g. from "Sign in to reply". */
  readonly formOpen = signal(false);

  /** After hydration only, so the prerendered page and the first render agree. */
  restore(): void {
    if (this.browser) this.session.set(read<Session>(local, SESSION_KEY));
  }

  private get redirectUri(): string {
    return new URL('auth/', this.document.baseURI).href;
  }

  async signIn(serverInput: string): Promise<void> {
    const host = serverHost(serverInput);
    if (!host) throw new AuthError('server');
    const origin = `https://${host}`;
    const redirectUri = this.redirectUri;
    const apps = read<Record<string, AppRegistration>>(local, APPS_KEY) ?? {};
    let app = apps[origin];
    if (!app || app.redirectUri !== redirectUri) {
      let response: Response;
      try {
        response = await fetch(`${origin}/api/v1/apps`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            client_name: this.site.title,
            redirect_uris: redirectUri,
            scopes: SCOPES,
            website: this.site.url,
          }),
        });
      } catch {
        throw new AuthError('network');
      }
      const registered = await json<{ client_id: string; client_secret: string }>(
        response,
        'register',
      );
      app = { clientId: registered.client_id, clientSecret: registered.client_secret, redirectUri };
      apps[origin] = app;
      write(local, APPS_KEY, apps);
    }
    const state = randomState();
    const pending: Pending = { origin, state, returnTo: this.document.location.href };
    write(session, PENDING_KEY, pending);
    this.document.location.assign(authorizeUrl(origin, app.clientId, redirectUri, state));
  }

  /** Finishes sign-in on the auth/ page. Returns the page to go back to. */
  async complete(search: string): Promise<string> {
    const params = new URLSearchParams(search);
    const pending = read<Pending>(session, PENDING_KEY);
    write(session, PENDING_KEY, null);
    if (params.get('error')) throw new AuthError('denied');
    const code = params.get('code');
    if (!pending || !code || params.get('state') !== pending.state) throw new AuthError('state');
    const app = read<Record<string, AppRegistration>>(local, APPS_KEY)?.[pending.origin];
    if (!app) throw new AuthError('state');
    try {
      const token = await json<{ access_token: string }>(
        await fetch(`${pending.origin}/oauth/token`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            grant_type: 'authorization_code',
            code,
            client_id: app.clientId,
            client_secret: app.clientSecret,
            redirect_uri: app.redirectUri,
            scope: SCOPES,
          }),
        }),
        'token',
      );
      const account = await json<{
        acct: string;
        display_name: string;
        username: string;
        avatar_static?: string;
        url: string;
      }>(
        await fetch(`${pending.origin}/api/v1/accounts/verify_credentials`, {
          headers: { Authorization: `Bearer ${token.access_token}` },
        }),
        'token',
      );
      const signedIn: Session = {
        origin: pending.origin,
        token: token.access_token,
        handle: fullHandle(account.acct, pending.origin),
        displayName: account.display_name?.trim() || account.username,
        avatar: account.avatar_static || null,
        url: account.url,
      };
      write(local, SESSION_KEY, signedIn);
      this.session.set(signedIn);
    } catch (error) {
      throw error instanceof AuthError ? error : new AuthError('network');
    }
    return safeReturn(pending.returnTo, this.document.baseURI);
  }

  async signOut(): Promise<void> {
    const current = this.session();
    this.session.set(null);
    write(local, SESSION_KEY, null);
    const app = current && read<Record<string, AppRegistration>>(local, APPS_KEY)?.[current.origin];
    if (current && app) {
      // Best effort: the token is gone from this browser either way.
      void fetch(`${current.origin}/oauth/revoke`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: app.clientId,
          client_secret: app.clientSecret,
          token: current.token,
        }),
      }).catch(() => undefined);
    }
  }

  /**
   * Posts a public reply from the reader's own server. Their server first looks
   * the status up by URL (it may not have seen it yet), then replies to its own
   * copy, which federates back to the original thread.
   */
  async reply(statusUrl: string, text: string): Promise<{ url: string }> {
    const current = this.session();
    if (!current) throw new AuthError('state');
    const headers = { Authorization: `Bearer ${current.token}` };
    // A revoked token signs the reader out instead of failing forever.
    const call = async (path: string, init: RequestInit = {}) => {
      const response = await fetch(`${current.origin}${path}`, init);
      if (response.status === 401) {
        void this.signOut();
        throw new AuthError('token');
      }
      return response;
    };
    const search = new URLSearchParams({ q: statusUrl, type: 'statuses', resolve: 'true', limit: '1' });
    const found = await json<{ statuses: MastodonStatus[] }>(
      await call(`/api/v2/search?${search}`, { headers }),
      'network',
    );
    const target = found.statuses[0];
    if (!target) throw new AuthError('network');
    const posted = await json<{ url?: string; uri: string }>(
      await call('/api/v1/statuses', {
        method: 'POST',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: text, in_reply_to_id: target.id, visibility: 'public' }),
      }),
      'network',
    );
    return { url: posted.url || posted.uri };
  }
}
