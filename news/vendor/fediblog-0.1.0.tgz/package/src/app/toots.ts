import { Injectable, inject } from '@angular/core';
import { Content } from './content';
import { linksTo, mawkingbirdLink } from './fediverse';
import { MastodonThread } from './model';

/** The fields of a public status this needs. */
export interface PublicToot {
  id: string;
  uri: string;
  url?: string | null;
  created_at: string;
  content?: string;
  card?: { url?: string | null } | null;
}

const PAGES = 3;
const PER_PAGE = 40;

/**
 * The site account's own recent public toots (the config's `mastodon`), read
 * anonymously in the browser. Used to find the toot that announced a post
 * whose front matter has no `mastodon:` line yet, so its comments work as soon
 * as it is published, before anyone edits the Markdown.
 */
@Injectable({ providedIn: 'root' })
export class SiteToots {
  private readonly site = inject(Content).site();
  private cached: Promise<PublicToot[]> | null = null;

  /** https://mastodon.social for @mawkingbird@mastodon.social. */
  get origin(): string | null {
    const match = /^@?[^@]+@(.+)$/.exec(this.site.mastodon ?? '');
    return match ? `https://${match[1]}` : null;
  }

  /** Newest first, up to 120. `fresh` skips this page's cache (after publishing). */
  toots(fresh = false): Promise<PublicToot[]> {
    if (!this.cached || fresh) this.cached = this.fetchToots().catch(() => []);
    return this.cached;
  }

  private async fetchToots(): Promise<PublicToot[]> {
    const origin = this.origin;
    const user = /^@?([^@]+)@/.exec(this.site.mastodon ?? '')?.[1];
    if (!origin || !user) return [];
    const get = async <T>(path: string): Promise<T> => {
      const response = await fetch(`${origin}${path}`, { headers: { Accept: 'application/json' } });
      if (!response.ok) throw new Error(`${response.status} ${path}`);
      return (await response.json()) as T;
    };
    const account = await get<{ id: string }>(`/api/v1/accounts/lookup?acct=${encodeURIComponent(user)}`);
    const toots: PublicToot[] = [];
    let maxId = '';
    for (let page = 0; page < PAGES; page += 1) {
      const query = new URLSearchParams({
        exclude_replies: 'true',
        exclude_reblogs: 'true',
        limit: String(PER_PAGE),
      });
      if (maxId) query.set('max_id', maxId);
      const batch = await get<PublicToot[]>(
        `/api/v1/accounts/${encodeURIComponent(account.id)}/statuses?${query}`,
      );
      toots.push(...batch);
      if (batch.length < PER_PAGE) break;
      maxId = batch[batch.length - 1].id;
    }
    return toots;
  }

  /** The thread for the site account's toot linking `postUrl`, if any. */
  async find(postUrl: string, fresh = false): Promise<MastodonThread | null> {
    const origin = this.origin;
    if (!origin) return null;
    // Oldest matching toot: the announcement, not a later "in case you missed it".
    const matches = (await this.toots(fresh)).filter((toot) => linksTo(toot, postUrl));
    const toot = matches[matches.length - 1];
    return toot ? this.thread(toot) : null;
  }

  thread(toot: PublicToot): MastodonThread {
    const origin = this.origin!;
    const thread = { server: origin, id: toot.id, url: toot.url || toot.uri };
    return {
      ...thread,
      mawkingbird: this.site.mawkingbird ? mawkingbirdLink(thread, this.site.mawkingbirdOrigin) : null,
    };
  }
}
