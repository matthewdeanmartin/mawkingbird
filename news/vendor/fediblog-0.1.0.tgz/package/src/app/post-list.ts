import { Component, inject, input } from '@angular/core';
import { Content } from './content';
import { formatDate, isoDate } from './format';
import { PostSummary } from './model';

@Component({
  selector: 'fb-post-list',
  template: `
    <ol class="fb-post-list">
      @for (post of posts(); track post.slug) {
        <li class="fb-card">
          <h2 class="fb-card-title"><a [href]="post.path">{{ post.title }}</a></h2>
          <p class="fb-meta">
            <time [attr.datetime]="iso(post.date)">{{ date(post.date) }}</time>
            · {{ post.readingMinutes }} min read
          </p>
          <p class="fb-card-description">{{ post.description }}</p>
          @if (post.tags.length) {
            <ul class="fb-tags" aria-label="Tags">
              @for (tag of post.tags; track tag.slug) {
                <li><a [href]="'tags/' + tag.slug + '/'">{{ tag.name }}</a></li>
              }
            </ul>
          }
        </li>
      } @empty {
        <li class="fb-empty">No posts yet.</li>
      }
    </ol>
  `,
})
export class PostList {
  readonly posts = input.required<PostSummary[]>();
  private readonly lang = inject(Content).site().lang;

  date(value: string): string {
    return formatDate(value, this.lang);
  }

  iso(value: string): string {
    return isoDate(value);
  }
}
