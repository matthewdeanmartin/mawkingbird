import { DOCUMENT, isPlatformServer } from '@angular/common';
import { Injectable, PLATFORM_ID, inject } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { Content } from './content';

export interface PageSeo {
  title: string;
  description: string;
  /** Site-relative path with a trailing slash ('' for the index). */
  path: string;
  type?: 'website' | 'article';
  image?: string | null;
  imageAlt?: string | null;
  lang?: string;
  published?: string;
  modified?: string | null;
  tags?: string[];
  /** BreadcrumbList trail after the site itself. */
  breadcrumbs?: { name: string; path: string }[];
}

/**
 * Head tags for one page. Written only while prerendering: every link is a
 * full page load, so the browser never needs to change them.
 */
@Injectable({ providedIn: 'root' })
export class Seo {
  private readonly document = inject(DOCUMENT);
  private readonly meta = inject(Meta);
  private readonly title = inject(Title);
  private readonly content = inject(Content);
  private readonly server = isPlatformServer(inject(PLATFORM_ID));

  set(page: PageSeo): void {
    if (!this.server) return;
    const site = this.content.site();
    const url = new URL(page.path, site.url).href;
    const fullTitle = page.path ? `${page.title} · ${site.title}` : site.title;
    const image = page.image ?? site.image;
    this.document.documentElement.lang = page.lang ?? site.lang;
    this.title.setTitle(fullTitle);

    const tags: Record<string, string>[] = [
      { name: 'description', content: page.description },
      { property: 'og:type', content: page.type ?? 'website' },
      { property: 'og:site_name', content: site.title },
      { property: 'og:title', content: page.title },
      { property: 'og:description', content: page.description },
      { property: 'og:url', content: url },
      { property: 'og:locale', content: (page.lang ?? site.lang).replace('-', '_') },
      { name: 'twitter:card', content: image ? 'summary_large_image' : 'summary' },
      { name: 'twitter:title', content: page.title },
      { name: 'twitter:description', content: page.description },
    ];
    if (image) {
      tags.push({ property: 'og:image', content: image }, { name: 'twitter:image', content: image });
      if (page.imageAlt) {
        tags.push(
          { property: 'og:image:alt', content: page.imageAlt },
          { name: 'twitter:image:alt', content: page.imageAlt },
        );
      }
    }
    if (site.mastodon) {
      // Mastodon credits the account on link previews of this page.
      tags.push({ name: 'fediverse:creator', content: site.mastodon.replace(/^@?/, '@') });
    }
    if (page.type === 'article' && page.published) {
      tags.push({ property: 'article:published_time', content: new Date(page.published).toISOString() });
      if (page.modified) {
        tags.push({ property: 'article:modified_time', content: new Date(page.modified).toISOString() });
      }
      for (const tag of page.tags ?? []) tags.push({ property: 'article:tag', content: tag });
    }
    if (site.noindex) tags.push({ name: 'robots', content: 'noindex' });
    for (const tag of tags) this.meta.addTag(tag);

    if (site.icon) this.link({ rel: 'icon', href: site.icon });
    this.link({ rel: 'canonical', href: url });
    this.link({ rel: 'alternate', type: 'application/atom+xml', title: `${site.title} (Atom)`, href: new URL('atom.xml', site.url).href });
    this.link({ rel: 'alternate', type: 'application/rss+xml', title: `${site.title} (RSS)`, href: new URL('rss.xml', site.url).href });
    if (site.mastodon) {
      const [, user, host] = /^@?([^@]+)@(.+)$/.exec(site.mastodon) ?? [];
      if (user && host) this.link({ rel: 'me', href: `https://${host}/@${user}` });
    }

    const graph: Record<string, unknown>[] = [];
    if (page.type === 'article') {
      graph.push({
        '@type': 'BlogPosting',
        headline: page.title,
        description: page.description,
        url,
        mainEntityOfPage: url,
        datePublished: page.published ? new Date(page.published).toISOString() : undefined,
        dateModified: new Date(page.modified ?? page.published ?? Date.now()).toISOString(),
        inLanguage: page.lang ?? site.lang,
        keywords: page.tags?.length ? page.tags.join(', ') : undefined,
        image: image ?? undefined,
        author: { '@type': 'Organization', name: site.author.name, url: site.author.url ?? undefined },
        publisher: { '@type': 'Organization', name: site.author.name, url: site.author.url ?? undefined },
        isPartOf: { '@type': 'Blog', name: site.title, url: site.url },
      });
    } else if (!page.path) {
      graph.push({ '@type': 'Blog', name: site.title, description: site.description, url: site.url, inLanguage: site.lang });
    }
    const trail = [{ name: site.title, path: '' }, ...(page.breadcrumbs ?? [])];
    if (trail.length > 1) {
      graph.push({
        '@type': 'BreadcrumbList',
        itemListElement: trail.map((crumb, index) => ({
          '@type': 'ListItem',
          position: index + 1,
          name: crumb.name,
          item: new URL(crumb.path, site.url).href,
        })),
      });
    }
    if (graph.length) {
      const script = this.document.createElement('script');
      script.type = 'application/ld+json';
      // `<` is escaped so post text can never close the script element.
      script.textContent = JSON.stringify({ '@context': 'https://schema.org', '@graph': graph }).replace(/</g, '\\u003c');
      this.document.head.appendChild(script);
    }
  }

  private link(attributes: Record<string, string>): void {
    const link = this.document.createElement('link');
    for (const [name, value] of Object.entries(attributes)) link.setAttribute(name, value);
    this.document.head.appendChild(link);
  }
}
