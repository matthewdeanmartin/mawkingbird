import { DOCUMENT } from '@angular/common';
import { Injectable, inject } from '@angular/core';
import { Content } from './content';

interface GoatCounter {
  count?(vars: { path: string }): void;
  no_onload?: boolean;
}

declare global {
  interface Window {
    goatcounter?: GoatCounter;
  }
}

/** Pages that are not reading: the sign-in return and the publishing desk. */
const UNCOUNTED = /\/(auth|publish)\/?$/;

/**
 * Optional GoatCounter page views (config `goatcounter`). Each page is its own
 * load, so this counts once, after hydration, with the path only (no query
 * string: auth/ carries an OAuth code there). Never on a noindex preview build,
 * and never when the visitor opted out in the config's `optOut` storage field
 * (Mawkingbird News honours the app's own analytics switch). The script is
 * the site's own copy: under this CSP no third-party script can run here.
 */
@Injectable({ providedIn: 'root' })
export class Analytics {
  private readonly site = inject(Content).site();
  private readonly document = inject(DOCUMENT);

  /** True when the visitor turned analytics off (the config's optOut field is false). */
  private optedOut(): boolean {
    const optOut = this.site.goatcounter?.optOut;
    if (!optOut) return false;
    try {
      const stored = JSON.parse(localStorage.getItem(optOut.storageKey) ?? '{}') as Record<string, unknown>;
      return stored[optOut.field] === false;
    } catch {
      return false;
    }
  }

  countPageView(): void {
    const config = this.site.goatcounter;
    const path = this.document.location.pathname;
    if (!config || this.site.noindex || UNCOUNTED.test(path) || this.optedOut()) return;
    const view = this.document.defaultView!;
    // Must exist before the script runs: it stops count.js counting on its own.
    view.goatcounter = { ...view.goatcounter, no_onload: true };
    const script = this.document.createElement('script');
    script.src = new URL(config.script, this.document.baseURI).href;
    script.async = true;
    script.dataset['goatcounter'] = config.endpoint;
    script.addEventListener('load', () => view.goatcounter?.count?.({ path }), { once: true });
    this.document.head.append(script);
  }
}
