import { Injectable, InjectionToken, TransferState, inject, makeStateKey } from '@angular/core';
import { Manifest, Post, PostSummary, Publishable, Site, Tag, summary } from './model';

/**
 * The whole manifest. Provided only on the server (app.config.server.ts reads
 * it from disk during prerender), so the browser bundle never contains posts.
 */
export const MANIFEST = new InjectionToken<Manifest | null>('fediblog manifest', {
  factory: () => null,
});

/**
 * Page data. On the server it comes from the manifest and is copied into
 * TransferState; in the browser, hydration reads back only what that page used.
 */
@Injectable({ providedIn: 'root' })
export class Content {
  private readonly manifest = inject(MANIFEST);
  private readonly state = inject(TransferState);

  private cached<T>(key: string, compute: (manifest: Manifest) => T): T {
    const stateKey = makeStateKey<T>(`fb:${key}`);
    if (this.manifest) {
      const value = compute(this.manifest);
      this.state.set(stateKey, value);
      return value;
    }
    return this.state.get(stateKey, null as T);
  }

  site(): Site {
    return this.cached('site', (m) => m.site);
  }

  posts(): PostSummary[] {
    return this.cached('posts', (m) => m.posts.map(summary));
  }

  post(slug: string): Post | null {
    return this.cached(`post:${slug}`, (m) => m.posts.find((p) => p.slug === slug) ?? null);
  }

  /** The posts either side of `slug` in date order: newer first, then older. */
  neighbours(slug: string): { newer: PostSummary | null; older: PostSummary | null } {
    return this.cached(`near:${slug}`, (m) => {
      const index = m.posts.findIndex((p) => p.slug === slug);
      return {
        newer: index > 0 ? summary(m.posts[index - 1]) : null,
        older: index >= 0 && index < m.posts.length - 1 ? summary(m.posts[index + 1]) : null,
      };
    });
  }

  /** Every post as the publish page needs it, newest first. */
  publishable(): Publishable[] {
    return this.cached('publishable', (m) =>
      m.posts.map(({ slug, title, description, path, date, lang, hashtags, mastodon }) => ({
        slug,
        title,
        description,
        path,
        date,
        lang,
        hashtags,
        mastodon: mastodon?.url ?? null,
      })),
    );
  }

  tags(): Tag[] {
    return this.cached('tags', (m) => m.tags);
  }

  tagged(slug: string): { tag: Tag | null; posts: PostSummary[] } {
    return this.cached(`tag:${slug}`, (m) => ({
      tag: m.tags.find((t) => t.slug === slug) ?? null,
      posts: m.posts.filter((p) => p.tags.some((t) => t.slug === slug)).map(summary),
    }));
  }
}
