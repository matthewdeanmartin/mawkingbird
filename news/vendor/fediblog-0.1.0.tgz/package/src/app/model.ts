import type { IconName } from './icon';

/** The manifest `fediblog build` writes and the prerender reads (see lib/content.mjs). */

export interface NavLink {
  label: string;
  href: string;
  /** One of the built-in icons (icon.ts); the label still shows on wide screens. */
  icon: IconName | null;
}

export interface Site {
  title: string;
  description: string;
  /** This build's address. Absolute, ends in a slash: https://example.com/news/ */
  url: string;
  /** The real address (config `url`); differs from `url` in a preview build. */
  canonicalUrl: string;
  /** Preview addresses (config `previews`) whose links in toots still count. */
  previewUrls: string[];
  basePath: string;
  lang: string;
  author: { name: string; url: string | null };
  /** `@you@server`, for fediverse:creator and the byline. */
  mastodon: string | null;
  image: string | null;
  /** Favicon URL. */
  icon: string | null;
  /** Small square image beside the site title in the top bar. */
  logo: string | null;
  nav: NavLink[];
  mawkingbird: boolean;
  /** Where "Reply in Mawkingbird" points (default https://mawkingbird.com). */
  mawkingbirdOrigin: string;
  footer: string | null;
  /** What the site's account toots when publishing a post. */
  publish: { hashtags: string[]; template: string };
  /** A preview copy: every page gets robots noindex. */
  noindex: boolean;
}

export interface TagRef {
  name: string;
  slug: string;
}

export interface MastodonThread {
  server: string;
  id: string;
  url: string;
  /** "Reply in Mawkingbird" link, or null when the site turned it off. */
  mawkingbird: string | null;
}

export interface PostSummary {
  slug: string;
  path: string;
  title: string;
  description: string;
  date: string;
  updated: string | null;
  tags: TagRef[];
  readingMinutes: number;
}

export interface Post extends PostSummary {
  image: string | null;
  imageAlt: string | null;
  lang: string;
  mastodon: MastodonThread | null;
  hiddenReplies: string[];
  /** Site defaults plus the post's own, without "#". */
  hashtags: string[];
  html: string;
}

/** One row of the publish page. */
export interface Publishable {
  slug: string;
  title: string;
  description: string;
  path: string;
  date: string;
  lang: string;
  hashtags: string[];
  /** The toot named in front matter, if any. */
  mastodon: string | null;
}

export interface Tag extends TagRef {
  count: number;
}

export interface Manifest {
  site: Site;
  posts: Post[];
  tags: Tag[];
}

export function summary(post: Post): PostSummary {
  const { slug, path, title, description, date, updated, tags, readingMinutes } = post;
  return { slug, path, title, description, date, updated, tags, readingMinutes };
}
