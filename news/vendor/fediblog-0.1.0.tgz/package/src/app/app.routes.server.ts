import { inject } from '@angular/core';
import { RenderMode, ServerRoute } from '@angular/ssr';
import { MANIFEST } from './content';

function manifest() {
  const value = inject(MANIFEST);
  if (!value) throw new Error('fediblog: no manifest. Build with `fediblog build`.');
  return value;
}

export const serverRoutes: ServerRoute[] = [
  {
    path: 'posts/:slug',
    renderMode: RenderMode.Prerender,
    getPrerenderParams: async () => manifest().posts.map((post) => ({ slug: post.slug })),
  },
  {
    path: 'tags/:tag',
    renderMode: RenderMode.Prerender,
    getPrerenderParams: async () => manifest().tags.map((tag) => ({ tag: tag.slug })),
  },
  { path: '**', renderMode: RenderMode.Prerender },
];
