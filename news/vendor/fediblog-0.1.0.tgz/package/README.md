# fediblog

A static blog engine, built with Angular, whose comments are Mastodon replies.

Write posts in Markdown. Toot each post from your Mastodon account and paste the
status URL into the post's front matter. The replies to that toot become the
post's comments, loaded in the reader's browser straight from your server's
public API. You don't need a comment database, an account system or a server.

Made for [Mawkingbird News](https://mawkingbird.com/news/). MIT licensed.

## What you get

- Prerendered static pages for the index, each post, each tag and an archive.
  Every page works without JavaScript and can be hosted at any base path.
- Atom and RSS feeds and a sitemap.
- Canonical URLs with trailing slashes, Open Graph and Twitter cards,
  `BlogPosting` and `BreadcrumbList` structured data, and the
  `fediverse:creator` meta tag, so Mastodon link previews credit your account.
- Comments: replies shown as a thread, sanitized, with custom emoji and
  collapsed content warnings. Only public and unlisted replies are shown, and
  your own replies are marked "Author". Comments are fetched after the page
  loads and are never prerendered, so other people's posts are not published
  for search engines.
- **Reply on Mastodon** asks for the reader's server and opens its
  `authorize_interaction` page for your toot. **Reply in Mawkingbird** opens the
  toot in [Mawkingbird](https://mawkingbird.com/), where a signed-in reader can
  reply as themselves. Set `"mawkingbird": false` to remove that button.
- Themes are plain CSS custom properties (`--fb-*`).

## Use

Requires Node 22.18 or newer.

```sh
npm install --save-dev fediblog
npx fediblog check --config fediblog.config.json
npx fediblog build --config fediblog.config.json --out dist/news
```

`build` deletes and rewrites `--out`, so it refuses to touch a folder that isn't
empty and doesn't look like an earlier fediblog build (it checks for `atom.xml`).
Pass `--drafts` to include posts marked `draft: true`. For a preview copy at
another address, pass `--url https://example.com/preview/news/ --noindex`: pages
get `robots: noindex` and no sitemap is written.

### fediblog.config.json

```json
{
  "title": "Example News",
  "description": "What changed, and why.",
  "url": "https://example.com/news/",
  "lang": "en",
  "author": { "name": "Example", "url": "https://example.com/" },
  "mastodon": "@example@mastodon.social",
  "posts": "posts",
  "static": "static",
  "theme": ["theme.css"],
  "image": "static/card.png",
  "icon": "https://example.com/favicon.png",
  "nav": [{ "label": "Home", "href": "https://example.com/" }],
  "footer": "Optional footer line.",
  "mawkingbird": true
}
```

`url` is the published address. Its path becomes the base href. Paths in the
file are relative to the config file. `static` is copied into the output
unchanged, which is where images go. `theme` lists CSS files, joined into
`theme.css` in that order.

### A post

`posts/2026-11-07-hello.md`. The date prefix is optional, and the slug is the
rest of the file name unless `slug:` is set.

```markdown
---
title: Hello, fediverse
description: One or two sentences for the index, feeds and link previews.
date: 2026-11-07
updated: 2026-11-08
tags: [Announcements]
image: images/hello.png
imageAlt: What the image shows
mastodon: https://mastodon.social/@example/113497012345678901
hiddenReplies:
  - https://mastodon.social/@someone/113497099999999999
---

Markdown body. Relative links resolve against the site's base URL.
```

Add `mastodon:` after you toot the post, then rebuild. A post without it has no
comments section. `hiddenReplies` takes status URLs, URIs or IDs. A hidden
reply's own replies are hidden with it.

### Theming

Override any of these on `:root` in your theme file:
`--fb-bg`, `--fb-surface`, `--fb-text`, `--fb-muted`, `--fb-border`,
`--fb-link`, `--fb-accent`, `--fb-accent-soft`, `--fb-button-bg`,
`--fb-button-text`, `--fb-focus`, `--fb-error`, `--fb-font`,
`--fb-font-prose`, `--fb-font-mono`, `--fb-radius` and `--fb-width`. The
defaults follow the reader's light or dark preference.

### When comments can't load

Servers that use authorized fetch or limited federation refuse anonymous API
reads. In that case, and when JavaScript is off, the comments section shows a
"Read the replies on Mastodon" link instead.

## How it works

The package contains a small Angular app. `fediblog build` reads your config and
posts into a JSON manifest, then runs the Angular build with static output. The
prerender reads the manifest from disk, so the browser bundle contains no posts.
Hydration gets only the data for the current page. Links are plain links, so
each page loads on its own. Afterwards the CLI writes the theme, the feeds and
the sitemap, and checks that every expected page exists.

## Develop

```sh
npm install
npm run check        # typecheck, unit tests, build the example, browser check
```

The browser check uses Playwright's Chromium (`npx playwright install chromium`).
