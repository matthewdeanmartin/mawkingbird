# fediblog

A static blog engine, built with Angular, whose comments are Mastodon replies.

Write posts in Markdown. Toot each post from your Mastodon account and paste the
status URL into the post's front matter. The replies to that toot become the
post's comments, loaded in the reader's browser straight from your server's
public API. You don't need a comment database, an account system or a server.

Made for [Mawkingbird News](https://mawkingbird.com/news/). MIT licensed.

## What you get

- Prerendered static pages for the index, each post, each tag and an archive.
  Every page works without JavaScript and can be hosted at any base path.
- Atom and RSS feeds and a sitemap.
- Canonical URLs with trailing slashes, Open Graph and Twitter cards,
  `BlogPosting` and `BreadcrumbList` structured data, and the
  `fediverse:creator` meta tag, so Mastodon link previews credit your account.
- Comments: replies shown as a thread, sanitized, with custom emoji and
  collapsed content warnings. Only public and unlisted replies are shown, and
  your own replies are marked "Author". Comments are fetched after the page
  loads and are never prerendered, so other people's posts are not published
  for search engines.
- **Sign in with Mastodon** (top bar) and reply on the page itself. The reader
  signs in on their own server with OAuth. The site registers itself as an app
  there, keeps the token in that browser only, and asks only for
  `read:accounts read:search write:statuses`. A reply is posted from the
  reader's account, so it joins the thread like any other reply. Readers can
  reply to the post or to one comment.
- **Publishing from the blog.** Signed in as the site's own account (the
  config's `mastodon`), the account menu offers **Publish posts**. That page
  lists every post as linked (front matter names its toot), found (the account
  already tooted a link to it) or not published. For a post that isn't
  published, it prefills an editable toot from a template (title, description,
  link, hashtags) and publishes it. Any other account can only comment.
- Without signing in, **Reply on your server** asks for the reader's server and
  opens its `authorize_interaction` page for your toot, and **Reply in
  Mawkingbird** opens the toot in [Mawkingbird](https://mawkingbird.com/). Set
  `"mawkingbird": false` to remove that button.
- A page frame like a social app's: the top bar's title, menu icons and sign-in
  sit over a left rail, a centre column and a right rail, which collapse on
  narrower screens.
- Themes are plain CSS custom properties (`--fb-*`).

## Use

Requires Node 22.18 or newer.

```sh
npm install --save-dev fediblog
npx fediblog check --config fediblog.config.json
npx fediblog build --config fediblog.config.json --out dist/news
npx fediblog link --config fediblog.config.json   # before build, see below
```

`build` deletes and rewrites `--out`, so it refuses to touch a folder that isn't
empty and doesn't look like an earlier fediblog build (it checks for `atom.xml`).
Pass `--drafts` to include posts marked `draft: true`. For a preview copy at
another address, pass `--url https://example.com/preview/news/ --noindex`: pages
get `robots: noindex` and no sitemap is written.

### fediblog.config.json

```json
{
  "title": "Example News",
  "description": "What changed, and why.",
  "url": "https://example.com/news/",
  "lang": "en",
  "author": { "name": "Example", "url": "https://example.com/" },
  "mastodon": "@example@mastodon.social",
  "posts": "posts",
  "static": "static",
  "theme": ["theme.css"],
  "image": "static/card.png",
  "icon": "https://example.com/favicon.png",
  "logo": "https://example.com/logo.png",
  "nav": [{ "label": "Home", "href": "https://example.com/", "icon": "home" }],
  "footer": "Optional footer line.",
  "mawkingbird": true,
  "publish": {
    "hashtags": ["example", "fediverse"],
    "template": "{title}\n\n{description}\n\n{url}\n\n{hashtags}"
  }
}
```

`url` is the published address. Its path becomes the base href. Paths in the
file are relative to the config file. `static` is copied into the output
unchanged, which is where images go. `theme` lists CSS files, joined into
`theme.css` in that order. `logo` is a small square image beside the title.
`nav` links go in the top bar after Archive. Each can name an `icon`: `home`,
`archive`, `help`, `info`, `app`, `rss`, `tag` or `user`. Labels hide on
narrower screens, leaving the icon, so a link without an icon keeps its label.

### A post

`posts/2026-11-07-hello.md`. The date prefix is optional, and the slug is the
rest of the file name unless `slug:` is set.

```markdown
---
title: Hello, fediverse
description: One or two sentences for the index, feeds and link previews.
date: 2026-11-07
updated: 2026-11-08
tags: [Announcements]
image: images/hello.png
imageAlt: What the image shows
hashtags: [FediTips]
mastodon: https://mastodon.social/@example/113497012345678901
hiddenReplies:
  - https://mastodon.social/@someone/113497099999999999
---

Markdown body. Relative links resolve against the site's base URL.
```

`tags` organise the blog (topic pages, `article:tag`). `hashtags` are only for
the toot that announces the post, so people on Mastodon can find it. They are
added to the config's `publish.hashtags` and never appear on the page.

Comments need the post's toot. Publish from the blog (above), or toot a link to
the post yourself from the site account. A post without `mastodon:` looks
through that account's latest public toots (up to 120, two to four public API
calls, only on such posts) for one that links it, and uses the oldest match.
Adding `mastodon:` skips the lookup and keeps working however old the toot
gets. `fediblog link` does that for you: it reads the site account's latest
public toots (up to 400) and writes `mastodon: <url>` as the last front matter
line of every published post that has none, leaving the rest of the file
untouched. Run it before `build` (`--dry-run` only reports) and commit the
result. The publish page also shows the line, with Copy. Until a toot exists, the
post says comments open once it is shared on Mastodon. `hiddenReplies` takes status URLs, URIs or IDs. A hidden
reply's own replies are hidden with it.

### Theming

Override any of these on `:root` in your theme file:
`--fb-bg`, `--fb-surface`, `--fb-text`, `--fb-muted`, `--fb-border`,
`--fb-link`, `--fb-accent`, `--fb-accent-soft`, `--fb-button-bg`,
`--fb-button-text`, `--fb-focus`, `--fb-error`, `--fb-font`,
`--fb-font-prose`, `--fb-font-mono` and `--fb-radius`. The defaults follow
the reader's light or dark preference.

The page grid: `--fb-rail-left` (290px), `--fb-column` (600px),
`--fb-rail-right` (320px), `--fb-gap` (16px), `--fb-max-width` (1460px) and
`--fb-topbar-height` (64px). The right rail drops below 1240px, the left rail
below 1000px, and menu labels below 1320px.

### Sign-in and storage

Signing in uses the page `auth/` (prerendered, `noindex`, not in the sitemap)
as the OAuth redirect address, so it must be reachable at your site's address.
The engine stores these keys in the reader's browser: `fediblog:session` and
`fediblog:apps` in localStorage, `fediblog:pending` in sessionStorage (during
sign-in), and `fediblog:server` (the last server typed). A site that shares
its origin with another app (say `/news/` beside an app at `/`) shares that
origin's storage, so the prefix keeps the keys apart. The sign-in is still
separate from that app's.

### When comments can't load

Servers that use authorized fetch or limited federation refuse anonymous API
reads. In that case, and when JavaScript is off, the comments section shows a
"Read the replies on Mastodon" link instead.

### Behind Cloudflare

Fediverse handles (`@me@example.social`) look like email addresses, so
Cloudflare's Email Address Obfuscation rewrites them, and after hydration they
show twice. Every page is wrapped in Cloudflare's `<!--email_off-->` markers, so
the blog is safe either way. Other pages on the same zone that print handles
are not: turn the setting off (Scrape Shield) for the zone or those paths.

## How it works

The package contains a small Angular app. `fediblog build` reads your config and
posts into a JSON manifest, then runs the Angular build with static output. The
prerender reads the manifest from disk, so the browser bundle contains no posts.
Hydration gets only the data for the current page. Links are plain links, so
each page loads on its own. Afterwards the CLI writes the theme, the feeds and
the sitemap, and checks that every expected page exists.

## Develop

```sh
npm install
npm run check        # typecheck, unit tests, build the example, browser check
```

The browser check uses Playwright's Chromium (`npx playwright install chromium`).
